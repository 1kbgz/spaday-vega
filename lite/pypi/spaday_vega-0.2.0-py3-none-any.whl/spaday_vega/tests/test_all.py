import ast
import re
from pathlib import Path

from spaday import generate
from spaday.bootstrap import bootstrap

from spaday_vega import TOKENS, VegaChart, package

ROOT = Path(__file__).parent.parent


def test_chart_serializes_declarative_properties():
    spec = {"$schema": "https://vega.github.io/schema/vega-lite/v6.json", "mark": "bar"}
    node = VegaChart(
        spec=spec,
        data={"values": [{"category": "A", "value": 12}]},
        signals={"threshold": 15},
        signal_listeners=["selected"],
        options={"theme": "quartz"},
        renderer="canvas",
        actions=True,
    ).to_node()

    assert node["tag"] == "vega-chart"
    assert node["props"]["spec"]["Map"]["mark"] == {"Str": "bar"}
    assert node["props"]["spec"]["Map"]["$schema"] == {"Str": "https://vega.github.io/schema/vega-lite/v6.json"}
    assert node["props"]["data"]["Map"]["values"]["List"][0]["Map"]["category"] == {"Str": "A"}
    assert node["props"]["signals"] == {"Map": {"threshold": {"Int": 15}}}
    assert node["props"]["signal_listeners"] == {"List": [{"Str": "selected"}]}
    assert node["props"]["options"] == {"Map": {"theme": {"Str": "quartz"}}}
    assert node["props"]["renderer"] == {"Str": "canvas"}
    assert node["props"]["actions"] == {"Bool": True}
    assert "vega-signal" in VegaChart.schema.events


def test_package_drives_bootstrap_assets_and_catalog():
    assert [schema.tag for schema in package.catalog] == ["vega-chart"]
    html = bootstrap(packages=[package])
    assert 'href="/components/vega/css/index.css"' in html
    assert 'src="/components/vega/cdn/index.js"' in html


def test_generated_component_is_current():
    fresh = generate(str(ROOT / "components.cem.json"))
    assert ast.dump(ast.parse(fresh)) == ast.dump(ast.parse((ROOT / "components.py").read_text(encoding="utf-8")))


def test_tokens_document_exactly_what_the_stylesheet_exposes():
    css = re.sub(r"\s+", "", (ROOT.parent / "js" / "src" / "css" / "index.css").read_text(encoding="utf-8"))
    read = set(re.findall(r"var\((--spa-vega-[a-z-]+)[,)]", css))
    assert read == {prop for prop, _ in TOKENS.values()}
    assert not re.findall(r"(?<![-\w])(--spa-vega-[a-z-]+):", css)


def test_structured_fallbacks_match_the_stylesheet():
    css = re.sub(r"\s+", "", (ROOT.parent / "js" / "src" / "css" / "index.css").read_text(encoding="utf-8"))
    for token in TOKENS.values():
        prop = token.property
        fallback = token.fallback
        private = prop.replace("--spa-", "--_spa-")
        [definition] = re.findall(rf"{private}:([^;]+);", css)
        assert f"var({fallback}," in definition
